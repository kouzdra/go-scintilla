class Demo
	def test # A test
		i = 1
		puts "Example"
	end
end